#include <debug.h>
#include <string.h>
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "off_t.h"
#include "devices/block.h"

#define CACHE_SIZE 64                          /* the maximum number of cache blocks */


void cache_init (void);
void cache_read(block_sector_t sector,void *buffer, int offset, int read_size);
void cache_write(block_sector_t sector,void *buffer, int offset, int write_size);
int  cache_find(block_sector_t sector);
void cache_write_back(int block_index);
void cache_write_all_back(void);
void cache_clear(int block_index);
void cache_clear_all(void);
int  cache_fetch(block_sector_t sector);
int  cache_evict(void);

