#include <debug.h>
#include <string.h>
#include "filesys/cache.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

#define CACHE_SIZE 64

/* struct cache block */
struct cache_block
  {
    bool valid;                          /* true: this block is valid */
    bool dirty;                          /* true: this block has been modified */ 
    block_sector_t sector_index;         /* sector index of the data in block */   
    uint8_t data[BLOCK_SECTOR_SIZE];     /* the size of each block is 512 bytes */
    struct lock single_cache_lock;       /* lock for every block in cache */
    size_t chance_value;                 /* for clock algorithm */ 
  };


/* Array contains all the cache blocks */
static struct cache_block cache[CACHE_SIZE];

/* Judge if cache has been initialized */
static bool cache_isCreated = false;

/* A lock for operations on the entire cache */
static struct lock cache_lock;

/* the number of valid cache blocks */
static int valid_block_num;


/* Initialize the cache. */
void
cache_init (void)
{
  
  lock_init (&cache_lock);

  /* Initialize each cache block. */
  int i;
  for (i = 0; i < CACHE_SIZE; i++)
    {
      cache[i].valid = false;
      cache[i].dirty = false;
      lock_init (&cache[i].single_cache_lock);
    }
  valid_block_num = 1;
  cache_isCreated = true;
}


/* write back the indicated cache block to the disk */
void 
cache_write_back(int block_index) {
    
    /* make sure the disk can be written */
    if (!cache_isCreated | (fs_device == NULL) ) 
        return;

    /* the block write back must be dirty and valid */
    if (!cache[block_index].dirty | !cache[block_index].valid) 
        return;

    /* write the data back and set dirty value as 0 */
    block_write (fs_device, cache[block_index].sector_index, cache[block_index].data);
    cache[block_index].dirty = 0;

}


/* write the whole cache back to disk */
void 
cache_write_all_back() {

    /* make sure the disk can be written */
    if (!cache_isCreated | (fs_device == NULL) ) 
        return;

    int index;
    for ( index = 0; index < CACHE_SIZE; index ++ ) {
        lock_acquire( &cache[index].single_cache_lock );
        cache_write_back (index);
        lock_release ( &cache[index].single_cache_lock );
    }
}


/* clear single cache */
void 
cache_clear (int block_index) {

    /* make sure the disk can be written */
    if (!cache_isCreated | (fs_device == NULL) ) 
        return;

    /* if the block is dirty, write it back */
    if (cache[block_index].dirty && cache[block_index].valid) {
        cache_write_back(block_index);
        valid_block_num--;
    } 
    cache[block_index].valid = false;
}



/* clear the whole cache */
void 
cache_clear_all () {

    /* make sure the disk can be written */
    if (!cache_isCreated | (fs_device == NULL) ) 
        return;

    int index;
    for ( index = 0; index < CACHE_SIZE; index ++ ) {
        lock_acquire( &cache[index].single_cache_lock );
        cache_clear(index);
        lock_release ( &cache[index].single_cache_lock );
    }
    valid_block_num = 0;
}



/* find one cache block to kick out based clock algorithm
   return the cache block id when got the number */
int
cache_evict ()
{
  
  /* use the static int to mark the clock position */
  static size_t clock = 0;
  int i;

  /*  Use clock algorithm to kick out a block */
  while (true)
    {
      
      /* move the clock pointer */
      i = clock;
      clock++;
      clock %= CACHE_SIZE;

      lock_acquire (&cache[i].single_cache_lock);

      /* if the block is invalid,directly pick it */
      if (!cache[i].valid)
        {
          valid_block_num++;
          return i;
        }

       /* if the chance value is 0, pick it */
      if (cache[i].chance_value == 0) {
        /* write dirty block back to disk */
        if (cache[i].dirty) {
          cache_write_back (i);
        }
        return i;

      /* if the chance value is 1, minus 1 to it. */
      } else {
        cache[i].chance_value--;
      }

      lock_release (&cache[i].single_cache_lock);
    }
    
  /* Cache entry is valid if it got to this point. */
  return i;
}


/* fetch one block from disk to cache, return the cache index */
int
cache_fetch(block_sector_t sector) {

  lock_acquire (&cache_lock);
  

  int index = cache_evict ();

  /* set the invalid bit of evicted block as false */
  cache[index].valid = false;
  
  /* read the sector from disk, then insert into the cache block */
  block_read (fs_device, sector, cache[index].data);
  cache[index].valid = true;
  cache[index].dirty = false;
  cache[index].sector_index = sector;
  cache[index].chance_value = 1;

  lock_release (&cache_lock);

  return index;
}


/* Returns the index in the cache corresponding to the block holding sector_index. */
int
cache_find ( block_sector_t sector_index)
{
  int index;
  
  /* check if the sector is in cache. */
  for( index = 0; index < CACHE_SIZE; index++ ) {
      
      lock_acquire (&cache[index].single_cache_lock);

      // if the sector is in cache, return the block index directly
      if( cache[index].valid && cache[index].sector_index == sector_index)
          return index;

      lock_release (&cache[index].single_cache_lock);
  }

  /* cache miss, call cache_fetch */
  int i = cache_fetch (sector_index);

  return i;
}



/* Read data from cache starting from sector_index at position offest,
   into destination. */
void
cache_read (block_sector_t sector_index, void *read_data, off_t offset, int read_size)
{
    
  /* make sure the disk can be read */
  if (!cache_isCreated | (fs_device == NULL) | (read_size <= 0)) 
      return;

  /* cache_find () acquires single_cache_lock at index i. */
  int i = cache_find (sector_index);

  /* read the data to buffer and update the chance value */
  memcpy (read_data, cache[i].data + offset, read_size);
  cache[i].chance_value = 1;
  lock_release (&cache[i].single_cache_lock);
}



/* Write data from buffer to the cache in an indicated size and offset */
void
cache_write ( block_sector_t sector_index, void *write_data, off_t offset, int write_size)
{
  
  /* make sure the disk can be read */
  if (!cache_isCreated | (fs_device == NULL) | (write_size <= 0)) 
      return;

  /* cache_find () acquires single_cache_lock at index i. */
  int i = cache_find(sector_index);

  /*  write the data from buffer to cache block
        & update the chance value and dirty value */
  memcpy (cache[i].data + offset, write_data, write_size);
  cache[i].dirty = true;
  cache[i].chance_value = 1;
  lock_release (&cache[i].single_cache_lock);
}

